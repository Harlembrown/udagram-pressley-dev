Udagram: Your Own Instagram on AWS

This is my 2nd Udacity Code Developer Nanodegree Project 

CRITERIA
I have met the required SPECIFICATIONS per the rubrics as follows:

The project demonstrates an understanding of a good cloud git process.
Created an Elastic Beanstalk endpoint.
EB endpoint is visible in the AWS Management console.
I have submitted screenshots showing eb cli & eb init as well as npm run dev.
Please provide feedback and how to get the Archive.zip file.
Eventhough I have the .elasticbeanstalk folder with the config.yml--the Archive.zip is hidden. 
I cannot locate it even after success w/eb cli & init.
Here is my endpoint: udagrampressleydev.us-east-1.elasticbeanstalk.com
How do I change my EB health check status from Severe to Good.

